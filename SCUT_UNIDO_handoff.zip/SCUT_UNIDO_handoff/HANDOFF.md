# 交接说明 / Handoff — SCUT × UNIDO 植物纤维替代塑料合作

> 新对话使用方法：把整个 zip 上传，并告诉 Claude：“先读 HANDOFF.md，再继续优化。”

## 1. 背景

- **发起人**：王小慧老师，华南理工大学（SCUT）先进造纸与纸基材料全国重点实验室（简称“造纸全国重点实验室”）。
- **目标**：联合联合国工业发展组织（UNIDO）、行业协会和产业代表，推动成立关注植物纤维材料、纸基材料和绿色替代塑料的非政府、非营利、开放性国际学术—产业合作网络（联盟）。秘书处设在华南理工。
- **对接部门**：UNIDO SDG 创新与经济转型司（IET）下的公平生产、可持续标准与贸易处（PST）。
- **关键日期**：
  - 与联合国方面的 Teams 会议：**2026 年 11 月 12、13 日**，议程为中文。
  - 校内面谈：科研院、国际处副职领导，原定 11 月 3 日下午或 4 日上午。
  - 建议 **11 月 10 日前**拿到学校的原则同意和修改意见。
- **联盟名称备选**（暂不对外使用）：
  - 方案 1：全球植物纤维替代创新联盟 / Global Alliance for Plant-Fiber Substitution（GAPS）
  - 方案 2：国际植物纤维材料创新联盟 / International Plant-Fiber Innovation Alliance（IPFIA）

## 2. 当前口径（已确定的方向）

- 先做事、后建组织：以三项交付物开局，即核算方法 V0.1、技术—产业图谱、南南技术对话加培训。
- 合作网络**不具法人资格**，现阶段不登记；网络名称中不使用 UNIDO 名称和徽标。
- 对外统一表述为：“由华南理工大学主办、依据 MOU 与 UNIDO 合作的国际学术—产业合作网络”。
- UNIDO 不出资；学校承担第一阶段直接费用，**此项待学校确认**。
- 利益冲突：部分教师持有广州树合科技等企业股权，因此由独立检测认证机构主持评审，关联企业回避。

## 3. 文件清单

| 路径 | 说明 | 状态 |
|---|---|---|
| `current/00_文件解读与谈话要点.md/.pdf` | 两份文件的解读、14 项修改说明、与科研院和国际处的谈话要点 | **最新** |
| `current/01_Concept_Note_optimized.md/.docx/.pdf` | 给 UNIDO PST 的概念说明优化稿（英文，附中文摘要） | **最新** |
| `current/02_MOU_Draft_optimized.md/.docx/.pdf` | MOU 优化稿（中英对照，含附件一工作计划） | **最新** |
| `originals/02_Concept_Note_IET-PST.docx` | 用户上传的 Concept Note 原稿 | 原件 |
| `originals/03_MOU_Draft_SCUT-UNIDO1.docx` | 用户上传的 MOU 原稿 | 原件 |
| `superseded/SCUT-UNIDO_MOU_draft.*` | 本对话早期由 Claude 起草的 MOU（联盟版，含登记法人设想） | 已被取代，仅供参考 |
| `superseded/Alliance_materials_all.pdf` | 早期汇总：微信草稿、联盟名称、早期 MOU | 已被取代 |
| `tools/edit.py`、`tools/style.css` | 生成优化稿的替换脚本和 PDF 样式 | 可选 |

`.md` 是可编辑的源文件，修改时以 `.md` 为准；`.docx` 和 `.pdf` 都由它生成。PDF 中用 `<mark>` 黄色高亮的地方是待确认项。

## 4. 待办与未决事项

**需要学校确认后才能保留的表述**（Concept Note 第 11 节、中文摘要第八部分）：
- “学校领导已授权本建议”
- “学校承担第一阶段费用”
- “校长愿赴维也纳拜会”
- 来函联系窗口为国际处，联系人待补

**需要核实的事实**：
- UNIDO 现行的 IET 司、PST 处英文全称。
- “山东大学‘清洁能源创新’大学联盟、ITPO 北京支持”这一先例。
- 实验室官方英文名。目前统一为 State Key Laboratory of Advanced Papermaking and Paper-based Materials。
- 实验室面积（2.1 万平方米以上）、设备值（约 3.05 亿元）、A+ 学科等数据口径。
- MOU 第九条关于名称和徽标受《专门机构特权与豁免公约》保护的措辞，建议采用 UNIDO 法务的标准措辞。
- 产业伙伴是否同意具名，以及各企业中文全称（Qingqing New Materials、BOIT 的中文名待确认）。

**MOU 方括号待定项**：
- 期限（3 年）
- 终止通知期（3 个月）
- 指导委员会会议频率
- 共同知识产权归属，以及是否采用开放许可 CC BY 4.0
- 以哪个文本为准（英文为准，或中英文同等作准）

**建议补充的材料（目前没有）**：
1. 第一阶段指示性预算和秘书处人员方案（2 人，其中 1 人全职）
2. 产业伙伴同意情况清单
3. 11 月 12、13 日 Teams 会议的中文议程和发言口径
4. 一页纸汇报摘要，供领导快速阅读
5. 数据共享和保密协议模板、利益冲突申报表

## 5. 可以让新对话做的事

- 根据学校意见修改两份文件，并重新生成 PDF 和 Word
- 起草 11 月 12、13 日会议议程（中英文）和发言稿
- 起草一页纸汇报摘要、预算表、企业意向函模板
- 把 Concept Note 改写成更短的版本（2–3 页）
- 合作网络章程草案（与 MOU 第六条一致）

## 6. 生成 PDF 的方法（可选）

```bash
pandoc 01_Concept_Note_optimized.md -f gfm+yaml_metadata_block -s --embed-resources -c tools/style.css -o out.html
# 用 Chrome 或浏览器打印为 PDF；Word 版：
pandoc 01_Concept_Note_optimized.md -f gfm+yaml_metadata_block -o out.docx
```

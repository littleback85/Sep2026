import sys
S='/tmp/claude-0/-home-user-Sep2026/10db368c-a3e7-5814-aa3b-18f16d60360c/scratchpad/in/'
O='/home/user/Sep2026/UNIDO_review/'
def M(t): return f'<mark>{t}</mark>'
def apply(src, reps, dst, prepend=''):
    s=open(S+src,encoding='utf-8').read()
    for a,b in reps:
        n=s.count(a)
        if n!=1: sys.exit(f'{src}: {n} matches for: {a[:60]}')
        s=s.replace(a,b)
    open(O+dst,'w',encoding='utf-8').write(prepend+s)

# ---------- Concept Note ----------
cn=[
("Zhuzhou Times Huaxian for high-performance paper-based materials.",
 "Zhuzhou Times Huaxian for high-performance paper-based materials. Leading paper and packaging producers, including APP Sinar Mas, Nine Dragons Paper, Sun Paper and Yuto Packaging, are expected to contribute production-line data and to act as early users of the method. "+M("[Partner names to be used only after each company has confirmed in writing.]")),
("Two consequences follow and both should be explicit. The arrangement cannot be registered as an entity in China under the current rules on the establishment of international organizations in the territory, and we do not propose to attempt it. Any future legal registration would be a decision for the members, taken in whatever jurisdiction is appropriate, and would require separate approvals outside the scope of this note.",
 "No registration as a legal entity is proposed at this stage. Any future decision to seek legal personality would be taken by the members, in the appropriate jurisdiction and subject to the required approvals, and lies outside the scope of this note."),
("SCUT’s leadership has authorized this proposal and would meet the costs of the first phase. The President would welcome",
 M("[To be confirmed by SCUT before transmission:]")+" SCUT’s leadership has authorized this proposal and would meet the costs of the first phase. The President would welcome"),
("Correspondence on this note may be addressed to the Office of International Cooperation, South China University of Technology.",
 "Correspondence on this note may be addressed to the Office of International Cooperation, South China University of Technology, "+M("[contact name, email]")+", with technical questions to the State Key Laboratory "+M("[contact name, email]")+"."),
("不新设机构，不涉及人员编制","不新设法人机构，不需要UNIDO增加人员"),
("末端情景一项即使结果相差一倍以上","末端情景一项即可使结果相差一倍以上"),
("拟合作伙伴包括全球头部造纸企业：金光纸业（APP）、玖龙纸业和太阳纸业；头部包装企业：裕同科技；以及SCUT孵化企业广州树合科技有限公司等。",
 "拟合作伙伴包括：全球头部造纸企业金光纸业（APP）、玖龙纸业、太阳纸业；头部包装企业裕同科技；SCUT孵化企业广州树合科技有限公司（生物基阻隔涂层）；以及Qingqing New Materials（涂层与功能助剂）、BOIT（制浆造纸过程数据建模）、株洲时代华先（高性能纸基材料）。"+M("【企业中文全称及是否同意具名，须在发出前逐一书面确认】")),
("实验室内有教师是相关企业的创始人或股东，包括上述企业。","实验室内有教师是相关企业的创始人或股东，包括广州树合科技有限公司。"),
("华南理工大学已同意承担第一阶段直接费用；校长愿在UNIDO方便时赴维也纳拜会",
 M("【以下两项须经学校正式同意后方可保留】")+"华南理工大学已同意承担第一阶段直接费用；校长愿在UNIDO方便时赴维也纳拜会"),
]
apply('cn1.md',cn,'01_Concept_Note_optimized.md',
 '---\ntitle: "Concept Note (optimized draft)"\nsubtitle: "Plant-Fiber Materials for Plastic Substitution — SCUT × UNIDO IET/PST"\n---\n\n')

# ---------- MoU ----------
lab_old="State Key Laboratory of Advanced Paper and Paper-Based Materials"
lab_new="State Key Laboratory of Advanced Papermaking and Paper-based Materials"
mou=[
("**Recognizing SCUT's research, engineering and testing capacity in pulp and paper, plant-fiber materials and paper-based substitutes for plastics, anchored in the "+lab_old+" and the National Engineering Research Center for Paper and Pollution Control, and extending through partnerships with leading pulp and paper companies, including APP Sinar Mas, Sun Paper and Nine Dragons Paper, to pilot-scale production and industrial validation of nanocellulose and functional paper-based materials;**",
 "**Recognizing** SCUT's research, engineering and testing capacity in pulp and paper, plant-fiber materials and paper-based substitutes for plastics, anchored in the "+lab_new+" and the National Engineering Research Center for Paper and Pollution Control, and extending, through partnerships with pulp, paper and packaging enterprises, to pilot-scale production and industrial validation of nanocellulose and functional paper-based materials;"),
("**Noting the growing demand","**Noting** the growing demand"),
("environmental footprint guidelines;**","environmental footprint guidelines;"),
("**Desiring to cooperate","**Desiring** to cooperate"),
("sustainability standards and trade;**","sustainability standards and trade;"),
("methodologies, standards and conformity tools that are usable by member States and by producers in developing countries.",
 "methodologies and conformity tools that are usable by member States and by producers in developing countries, and to contribute technical inputs to the work of the relevant standardization bodies."),
("intended to substitute for plastics in defined applications.",
 "intended to substitute for plastics in defined applications. “The Network” means the international academic–industry cooperation network of participating institutions referred to in Article 6, which has no legal personality."),
("and promotion of mutual recognition of test methods.","with a view to improving the comparability of test results across markets."),
("3.  **Technology–industry mapping. Preparation","3.  **Technology–industry mapping.** Preparation"),
("from SCUT and its industrial partners.**","from SCUT and its industrial partners."),
("7.  **Industrial validation and demonstration. Pilot-scale validation and demonstration of plant-fiber substitutes for plastics, drawing on production data and demonstration lines of SCUT and its industrial partners, to support technology uptake by producers in developing countries.**",
 "7.  **Industrial validation and demonstration.** Pilot-scale validation of the methodologies under items 1 and 2, drawing on production data and demonstration lines of SCUT and its industrial partners, to support technology uptake by producers in developing countries."),
("host the secretariat of the cooperation network within the "+lab_old,"host the secretariat of the Network within the "+lab_new),
("6.  support pilot and demonstration activities for the technologies covered by this MoU, drawing on SCUT's technology-transfer and incubation capacity;",
 "6.  manage conflicts of interest arising from commercial interests of its staff in enterprises active in this field, in accordance with Article 6, paragraph 5;"),
("4.  The cooperation network may be described publicly as an international academic–industry cooperation network operating within the UNIDO partnership framework. It shall not be presented as a UNIDO office, subsidiary body or legally separate entity.",
 "4.  The Network may be described publicly as an international academic–industry cooperation network hosted by SCUT and cooperating with UNIDO under this MoU. It shall not use the name or emblem of UNIDO in its title, and shall not be presented as a UNIDO office, subsidiary body or legally separate entity.\n\n5.  **Independence of review.** The review of methodology drafts shall be chaired by an independent testing or certification body acceptable to both Parties. No enterprise in which SCUT staff hold a commercial interest shall take part in the review of a method that it would itself apply."),
("are intended to be disseminated as public goods.","are intended to be disseminated as public goods \\[under an open licence, such as CC BY 4.0 for texts and a permissive licence for software tools\\]."),
("Indicative work plan (12–18 months)","Indicative work plan (18 months)"),
("| Methodology Draft V0.1 validated against production data; first mapping version | Draft V0.1; mapping v1 ",
 "| Methodology Draft V0.1 validated against production data; mapping data collection | Draft V0.1; workbook (beta) "),
("| Review by testing and certification bodies; South–South technical dialogue      | Review report; forum report ",
 "| Independent review of Draft V0.1; mapping v1 published; training module drafted | Review report; mapping v1 "),
("| Revised methodology; published mapping; training module and pilot               | Methodology V1.0; mapping publication; training package ",
 "| Methodology V1.0; South–South technical dialogue; pilot training in one region | Methodology V1.0; forum report; training package "),
# Chinese
("**认识到 SCUT 在制浆造纸、植物纤维材料及纸基替代塑料材料领域的研究、工程化与检测能力，以先进造纸与纸基材料全国重点实验室和造纸与污染控制国家工程研究中心为依托，并通过与金光纸业（APP）、太阳纸业、玖龙纸业等龙头造纸企业的产业伙伴关系，延伸至纳米纤维素与功能纸基材料的中试放大与产业化验证；**",
 "**认识到** SCUT 在制浆造纸、植物纤维材料及纸基替代塑料材料领域的研究、工程化与检测能力，以先进造纸与纸基材料全国重点实验室和造纸与污染控制国家工程研究中心为依托，并通过与造纸、包装企业的产业伙伴关系，延伸至纳米纤维素与功能纸基材料的中试放大与产业化验证；"),
("**注意到成员国","**注意到**成员国"),
("推进相关方法开发；**","推进相关方法开发；"),
("**愿在支持","**愿**在支持"),
("示范方面开展合作；**","示范方面开展合作；"),
("可用的方法学、标准与合规工具。","可用的方法学与合规工具，并为相关标准化机构的工作提供技术输入。"),
("包括纸基材料与纳米纤维素产品。","包括纸基材料与纳米纤维素产品。本备忘录所称“合作网络”，指第六条所述由参与机构组成的国际学术—产业合作网络，不具有法人资格。"),
("推动检测方法的互认。","以提高不同市场间检测结果的可比性。"),
("3.  **技术—产业图谱：编制","3.  **技术—产业图谱**：编制"),
("SCUT 及其产业伙伴的生产与中试数据。**","SCUT 及其产业伙伴的生产与中试数据。"),
]
s=open(S+'mou1.md',encoding='utf-8').read()
# find Chinese item 7 and 6.4 full lines
import re
l7=[l for l in s.splitlines() if l.startswith('7.  **产业化验证与示范')][0]
l64=[l for l in s.splitlines() if l.startswith('4.  合作网络对外可表述')][0]
l56=[l for l in s.splitlines() if l.startswith('6.  依托 SCUT')][0]
mou+=[
(l7,"7.  **产业化验证与示范**：依托 SCUT 及其产业伙伴的生产数据与示范线，对第1、2项所开发的方法开展中试与产业化验证，支持发展中国家生产商的技术应用。"),
(l56,"6.  对本校人员在相关企业中持有商业利益所产生的利益冲突进行管理，具体按第六条第5款执行；"),
(l64,"4.  合作网络对外可表述为“由华南理工大学主办、依据本备忘录与 UNIDO 开展合作的国际学术—产业合作网络”；网络名称不使用 UNIDO 名称与徽标，且不得表述为 UNIDO 的办公室、附属机构或独立法律实体。\n\n5.  **评审独立性**：方法学草案的评审由双方认可的独立检测或认证机构主持；SCUT 人员持有商业利益的企业，不参与其自身将采用之方法的评审。"),
("拟作为公共产品传播","拟作为公共产品\\[以开放许可方式，如文本采用 CC BY 4.0、软件工具采用宽松许可\\]传播"),
]
annex_cn='''

## 附件一　指示性工作计划（18个月）

| 时段 | 活动 | 产出 | 牵头方 |
|---|---|---|---|
| 第1–3月 | 技术对接；确认方法学范围；商定工作计划 | 工作计划；指定对接人 | UNIDO / SCUT |
| 第4–6月 | 方法学框架；数据采集规程；图谱方法 | 框架文件；数据规程 | SCUT |
| 第7–9月 | 以生产数据验证方法学草案 V0.1；图谱数据采集 | 草案 V0.1；计算工作簿（试用版） | SCUT 及产业伙伴 |
| 第10–12月 | 独立评审草案 V0.1；发布图谱第一版；编制培训模块 | 评审报告；图谱 v1 | UNIDO / SCUT |
| 第13–18月 | 发布方法学 V1.0；举办南南技术对话；在一个区域试点培训 | 方法学 V1.0；论坛报告；培训包 | SCUT / UNIDO |
'''
apply('mou1.md',mou,'02_MOU_Draft_optimized.md',
 '---\ntitle: "Memorandum of Understanding — UNIDO × SCUT (optimized draft)"\nsubtitle: "联合国工业发展组织与华南理工大学谅解备忘录（优化稿）"\n---\n\n')
p=O+'02_MOU_Draft_optimized.md'
open(p,'a',encoding='utf-8').write(annex_cn)
print('ok')
